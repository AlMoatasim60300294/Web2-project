
const persistence = require('./persistence')

async function allCourses() {
    return await persistence.readCourseData()
}

async function findCourse(code) {
    let courses = await persistence.readCourseData()
    for (c of courses) {
        if (c.code === code) {
            return {
                code: c.code,
                name: c.name,
                capacity: c.capacity
            }
        }
    }
    return undefined
}


async function minCapacityCourses(cap) {
    let result = []
    let data = await persistence.readCourseData()
    for (c of data) {
        if (c.capacity >= cap) {
            result.push(c)
        }
    }
    return result
}

// This function will update the capacity of a single course.  If the course code does not exist, print a message
// indicating that no course was found.
async function updateCapacity(code, capacity) {
    let courses = await persistence.readCourseData()
    let changed = false
    for (c of courses) {
        if (c.code === code && c.capacity != capacity) {
            c.capacity = capacity
            changed = true
        }
    }
    if (changed) {
        persistence.writeCourseData(courses)
    }
    return changed
}

module.exports = {
    allCourses,
    findCourse,
    minCapacityCourses,
    updateCapacity
}