const fs = require('fs/promises')

async function readCourseData() {
    let raw = await fs.readFile('courses.json', 'utf8')
    return await JSON.parse(raw)
}

async function writeCourseData(courseList) {
    await fs.writeFile('courses.json', JSON.stringify(courseList))
}


module.exports = {
    readCourseData,
    writeCourseData
}