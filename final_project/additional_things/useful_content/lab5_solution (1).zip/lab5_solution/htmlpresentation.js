const express=require('express')
const business=require('./business.js')
const bodyParser = require('body-parser')
app = express()
let urlencodedParser = bodyParser.urlencoded({extended: false})
app.use(urlencodedParser)

app.get('/', (req,res) => {
    let result = ""

    result += "<h1>Main Page</h1>"
    result += "<ul>"
    result += "<li><a href='/courses'>List All Courses</a></li>"
    result += "<li><a href='/find-course'>Find Course By Code</a></li>"
    result += "<li><a href='/update-course'>Update Capacity</a></li>"
    result += "</ul>"
    res.send(result)
})

app.get('/courses', async (req, res) => {
    let html = `
    <style>
        table {
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
        }
    </style>
    `
    html += "<h1>All Courses</h1>"
    let courses = await business.allCourses()
    
    html += "<table>"
    html += "<tr><th>Code</th><th>Name</th><th>Capacity</th></tr>"
    for (c of courses) {
        html += `<tr><td>${c.code}</td><td>${c.name}</td><td>${c.capacity}</td></tr>`
    }
    html += "</table>"
    res.send(html)
})

app.get('/find-course', (req,res) => {
    html = "<h1>Find Course</h1>"
    html += "<form action='/course-details' method='get'>"
    html += "Course Code: <input name='course_id'><input type='submit' value='Find'>"
    html += "</form>"
    res.send(html)
})

app.get('/course-details', async (req, res) => {
    let details = await business.findCourse(req.query.course_id)
    if (!details) {
        res.send("No course found")
    }
    else {
        let html = "<h1>Course Details</h1>"
        html += `Course Code: ${details.code}<br>`
        html += `Name: ${details.name}<br>`
        html += `Capacity: ${details.capacity}`
        res.send(html)
    }
})

app.get('/update-course', async (req, res) => {
    html = "<h1>Update Course Capacity</h1>"
    html += "<form method='post'>"
    html += "Code: <input name='course'><br>"
    html += "Capacity: <input name='capacity'><br>"
    html += "<input type='submit' value='Update'>"
    html += "</form>"
    res.send(html)

})

app.post('/update-course', async (req, res) => {
    let course = req.body.course
    let capacity = req.body.capacity
    let result = await business.updateCapacity(course, capacity)
    if (result) {
        res.send('The capacity was updated')
    }
    else {
        res.send('The capacity could not be updated')
    }
})

app.listen(8000, () => {
    console.log("Application started")
})