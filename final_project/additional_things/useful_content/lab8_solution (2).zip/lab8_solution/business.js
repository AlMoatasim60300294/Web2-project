
const persistence = require('./persistence')
const crypto = require('crypto')


async function validateCredentials(username, password) {
    return await persistence.validateCredentials(username, password)
}

async function startSession(data) {
    let sessionKey = crypto.randomUUID()
    let sd = {
        key: sessionKey,
        expiry: new Date(Date.now() + 1000*60*5), // 5 minutes
        data: data
    }
    await persistence.updateSession(sd)
    return sessionKey
}

async function generateToken(key) {
    let token = Math.floor(Math.random()*1000000)
    let sd = await persistence.getSession(key)
    sd.csrfToken = token
    await persistence.updateSession(sd)
    return token
}

async function getToken(key) {
    let sd = await persistence.getSession(key)
    return sd.csrfToken
}

async function cancelToken(key) {
    let sd = await persistence.getSession(key)
    sd.csrfToken = token
    await persistence.updateSession(sd)
}

async function getSession(key) {
    return await persistence.getSession(key)
}

async function terminateSession(key) {
    return await persistence.deleteSession(key)
}

async function registerUser(name, email, description) {
    let reg = {
        name: name,
        email: email,
        description: description,
        approved: false
    }
    return await persistence.createRegistration(reg)
}

async function getApplications() {
    return await persistence.getAllApplications()
}

async function approveRegistration(email) {
    return await persistence.updateApproval(email)
}

module.exports = {
    registerUser, getApplications, approveRegistration,
    validateCredentials,
    startSession, getSession, terminateSession,
    generateToken, cancelToken, getToken
}