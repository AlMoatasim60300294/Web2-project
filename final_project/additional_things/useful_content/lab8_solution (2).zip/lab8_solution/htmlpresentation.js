const express=require('express')
const business=require('./business.js')
const bodyParser = require('body-parser')
const handlebars = require('express-handlebars')
const cookieParser = require('cookie-parser')
const flash = require('./flash.js')

app = express()
app.set('views', __dirname+"/templates")
app.set('view engine', 'handlebars')
app.engine('handlebars', handlebars.engine())
let urlencodedParser = bodyParser.urlencoded({extended: false})
app.use(urlencodedParser)
app.use(cookieParser())

app.get('/', async (req, res) => {
    let key = req.cookies.session
    let message = await flash.getFlash(key)
    let sd = undefined
    if (key) {
        sd = await business.getSession(key)
    }
    if (sd && sd.data.username != "") {
        res.redirect('/dashboard')
        return
    }
    res.render('login', {
        layout: undefined,
        message: message
    })
})

app.post('/', async (req, res) => {
    let username = req.body.uname
    let password = req.body.pword
    let valid = await business.validateCredentials(username, password)
    if (valid) {
        let key = await business.startSession({username: username})
        res.cookie('session', key)
        res.redirect('/dashboard')
    }
    else {
        let key = await business.startSession({username:""})
        await flash.setFlash(key, "Invalid Credentials")
        res.cookie('session', key)
        res.redirect('/')
    }
})

app.get('/logout', async (req, res) => {
    let key = await business.startSession({username:""})
    await flash.setFlash(key, "Logged Out")
    res.cookie('session', key)
    res.redirect('/')
})

async function isAuthenticated(session) {
    if (!session) {
        return false
    }
    let sd = await business.getSession(session)
    if (sd && sd.data.username != "") {
        return true
    }
    return false
}

app.get('/dashboard', async (req,res) => {
    let key = req.cookies.session
    if (!await isAuthenticated(key)) {
        let key = await business.startSession({username:""})
        await flash.setFlash(key, "Please Login")
        res.cookie('session', key)
        res.redirect('/')
        return
    }

    // There are no user types here... if the person is logged in then they get to see everything.
    res.render('main', {layout: undefined})
})

app.get('/application', async (req, res) => {
    let key = req.cookies.session
    if (!key || !await isAuthenticated(key)) {
        let key = await business.startSession({username:""})
        await flash.setFlash(key, "Please Login")
        res.cookie('session', key)
        res.redirect('/')

        return
    }
    let apps = await business.getApplications()
    let csrfToken = await business.generateToken(key)
    res.render('applications', {
        layout: undefined,
        csrfToken: csrfToken,
        applications: apps
    })
})

app.post('/approve', async (req, res) => {
    let key = req.cookies.session
    if (!key || !(await isAuthenticated(key))) {
        let key = await business.startSession({username:""})
        await flash.setFlash(key, "Please Login")
        res.cookie('session', key)
        res.redirect('/')
        return
    }

    let token = await business.getToken(key)
    if (token != req.body.csrf) {
        res.status(403)
        res.send("Invalid CSRF Request")
        return
    }

    let email = req.body.email
    await business.approveRegistration(email)
    res.redirect('/application')
})

app.get('/registration', async (req, res) => {
    res.render('registration', {layout: undefined})
})

app.post('/registration', async (req, res) => {
    // save registration details and redirect to / with a message
    let name = req.body.name
    let email = req.body.email
    let description = req.body.description
    await business.registerUser(name, email, description)
    let key = await business.startSession({username:""})
    await flash.setFlash(key, "Registration complete, you will get an email when it is approved")
    res.cookie('session', key)
    res.redirect('/')
})


app.listen(8000, () => {
    console.log("Application started")
})