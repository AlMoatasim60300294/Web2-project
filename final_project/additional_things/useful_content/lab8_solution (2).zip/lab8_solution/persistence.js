const fs = require('fs')

async function validateCredentials(username, password) {
    let raw = fs.readFileSync('useraccounts.json')
    let data = JSON.parse(raw)
    for (let user of data) {
        if (user.username === username && user.password === password) {
            return true
        }
    }
    return false
}

// This function does several things.. If there is no session with the given key
// the session data will be saved.  If there is a session already with the key the
// session data is replaced.  
//
// Before looking however, the function will scan through existing session data and
// delete anything which is "expired".
async function updateSession(sd) {
    let raw = fs.readFileSync('session.json')
    let data = JSON.parse(raw)
    let result = []
    // first, remove any expired data
    for (let s of data) {
        if (s.expiry > Date.now()) {
            result.push(s)
        }
    }
    // try to find
    for (let s of result) {
        if (s.key == sd.key) {
            s.data = sd.data
            fs.writeFileSync('session.json', JSON.stringify(result))
            return
        }
    }
    result.push(sd)
    console.log('trying to write sessions in update')
    console.log(result)
    fs.writeFileSync('session.json', JSON.stringify(result))
}

async function getSession(key) {
    let raw = fs.readFileSync('session.json')
    let data = JSON.parse(raw)
    let temp = []
    let result = undefined
    let modified = false
    // first, remove any expired data
    for (let s of data) {
        let current = new Date(Date.now())
        let exp = new Date(s.expiry)
        if (exp > Date.now()) {
            temp.push(s)
        }
        else {
            modified = true
        }
    }
    for (let s of temp) {
        if (s.key === key) {
            result = s
            break
        }
    }
    if (modified) {
        fs.writeFileSync('session.json', JSON.stringify(temp))
    }
    return result
}

async function deleteSession(key) {
    let raw = fs.readFileSync('session.json')
    let data = await JSON.parse(raw)
    let temp = []
    for (let s of data) {
        if (s.key != key) {
            temp.push(s)
        }
    }
    await fs.writeFileSync('session.json', JSON.stringify(temp))
}

async function createRegistration(details) {
    let raw = fs.readFileSync('registrations.json')
    let data = JSON.parse(raw)
    data.push(details)
    fs.writeFileSync('registrations.json', JSON.stringify(data))
}

async function getAllApplications() {
    let raw = fs.readFileSync('registrations.json')
    let data = JSON.parse(raw)
    return data    
}

async function updateApproval(email) {
    let raw = fs.readFileSync('registrations.json')
    let data = JSON.parse(raw)
    for (let app of data) {
        if (app.email == email) {
            app.approved = true
        }
    }
    fs.writeFileSync('registrations.json', JSON.stringify(data))
}

module.exports = {
    validateCredentials,
    updateSession, getSession, deleteSession,
    createRegistration, getAllApplications, updateApproval
}