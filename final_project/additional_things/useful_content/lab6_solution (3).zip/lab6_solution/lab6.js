const { MongoClient } = require('mongodb')

let client = undefined

async function connectDatabase() {
    if (!client) {
        client = new MongoClient('mongodb+srv://robert:12class34@cluster0.qgtdkrd.mongodb.net/')
        await client.connect()
    }
}


async function getAllCourses() {
    await connectDatabase()
    let db = client.db('university')
    let course = db.collection('course')
    let result = await course.find()
    let resultData = await result.toArray()
    return resultData
}

async function getSingleCourse(cid) {
    await connectDatabase()
    let db = client.db('university')
    let course = db.collection('course')
    let result = await course.find({code: cid})
    let resultData = await result.toArray()
    return resultData[0]
}

async function updateCourseCapacity(cid, newCap) {
    await connectDatabase()
    let db = client.db('university')
    let course = db.collection('course')
    await course.updateOne({code: cid}, {$set: {capacity: newCap}})
}

async function main() {
    console.log('======= List of all Courses ======')
    let allCourses = await getAllCourses()
    console.log(allCourses)
    console.log('======= Single Details about INFS3201 =======')
    let details = await getSingleCourse('INFS3201')
    console.log(details)
    console.log("======= Updating the Capacity then Getting the Details Again ======")
    await updateCourseCapacity('INFS3201', 100)
    console.log(await getSingleCourse('INFS3201'))


    await client.close()
}


main()