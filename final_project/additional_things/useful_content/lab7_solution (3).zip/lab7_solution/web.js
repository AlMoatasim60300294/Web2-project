const express = require('express')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const business = require('./business.js')

let app = express()
const handlebars = require('express-handlebars')
app.set('views', __dirname+"/templates")
app.set('view engine', 'handlebars')
app.engine('handlebars', handlebars.engine())
app.use(bodyParser.urlencoded())
app.use(cookieParser())

app.get('/', (req, res) => {
    res.render('login', {layout: undefined, message: req.query.message})
})

app.post('/', async (req,res) => {
    let username = req.body.username
    let password = req.body.password
    if (username == "" || password == "") {
        res.redirect("/?message=Invalid Username/Password")
        return
    }
    let userType = await business.checkLogin(username, password)
    if (!userType) {
        res.redirect("/?message=Invalid Username/Password")
        return
    }

    // at this point the credentials are good so we will ask for a session....
    // storing the password in the session would be silly because we wouldn't want it
    // to be stored in plaintext (assume that the user collection doesn't use plaintext passwords)
    let session = await business.startSession({
        UserName: username,
        UserType: userType
    })
    res.cookie('lab7session', session.uuid, {expires: session.expiry})

    if (userType == 'admin') {
        res.redirect('/admin')
    }
    else if (userType == 'standard') {
        res.redirect('/standard')
    }
})


app.get('/standard', async (req, res) => {
    let sessionKey = req.cookies.lab7session
    if (!sessionKey) {
        res.redirect("/?message=Not logged in")
        return
    }
    let sessionData = await business.getSessionData(sessionKey)
    if (!sessionData) {
        res.redirect("/?message=Not logged in")
        return
    }

    if (sessionData && sessionData.Data && sessionData.Data.UserType && sessionData.Data.UserType != 'standard') {
        res.redirect("/?message=Invalid User Type")
        return
    }
    res.render('standard_landing', {layout: undefined, username: sessionData.Data.UserName})
})

app.get('/logout', async (req, res) => {
    await business.deleteSession(req.cookies.lab7session)
    res.cookie('lab7session', '', {expires: new Date(Date.now())})
    res.redirect('/')
})

app.get('/admin', async (req, res) => {
    let sessionKey = req.cookies.lab7session
    if (!sessionKey) {
        res.redirect("/?message=Not logged in")
        return
    }
    let sessionData = await business.getSessionData(sessionKey)
    if (!sessionData) {
        res.redirect("/?message=Not logged in")
        return
    }
    if (sessionData && sessionData.Data && sessionData.Data.UserType && sessionData.Data.UserType != 'admin') {
        res.redirect("/?message=Invalid User Type")
        return
    }
    res.render('admin_landing', {layout:undefined, username: sessionData.Data.UserName})
})




app.listen(8000, () => { console.log("Running")})