const persistence = require('./data')
const nodemailer = require('nodemailer')
const crypto = require('crypto')

async function attemptLogin(u, p) {
    let details = await persistence.getUserDetails(u)
    let hash = crypto.createHash('sha256')
    hash.update(p)
    let result = hash.digest('hex')
    if (details == undefined || details.password != result) {
        return undefined
    }
    
    let sessionKey = crypto.randomUUID()
    let sd = {
        key: sessionKey,
        expiry: new Date(Date.now() + 1000*60*5),
        data: {
            username: details.user
        }
    }
    await persistence.startSession(sd)
    return sd
}

async function terminateSession(key) {
    if (!key) {
        return
    }
    await persistence.terminateSession(key)
}

async function getSession(key) {
    return await persistence.getSession(key)
}




async function resetPassword(email) {
    let details = await persistence.getUserByEmail(email)
    if (details) {
        let key = crypto.randomUUID()
        details.resetkey = key
        await persistence.updateUser(details)
        
        let transporter = nodemailer.createTransport({
            host: "127.0.0.1",
            port: 25
        })

        let body = `
        A password reset request has been made for your account.  Please
        follow <a href="http://127.0.0.1:8000/reset-password/?key=${key}">this link</a>
        to set a new password for your account.`
        await transporter.sendMail({
            from: "lab9@infs3203.com",
            to: email,
            subject: "Password reset",
            html: body
        })
        console.log(body)
    }
    return undefined
}

async function checkReset(key) {
    return persistence.checkReset(key)
}

async function setPassword(key, pw) {
    let hash = crypto.createHash('sha256')
    hash.update(pw)
    let hashed_pw = hash.digest('hex')

    await persistence.updatePassword(key, hashed_pw)
}

module.exports = {
    attemptLogin, terminateSession, getSession,
    resetPassword, checkReset, setPassword
}