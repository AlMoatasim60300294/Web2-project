const mongodb = require('mongodb')

let client = undefined 
let db = undefined

async function connectDatabase() {
    if (!client) {
        client = new mongodb.MongoClient('mongodb://localhost:27017')
        db = client.db('nothing')
        await client.connect()
    }
}

async function getUserDetails(username) {
    await connectDatabase()
    let users = db.collection('user')
    let result = await users.findOne({user:username})
    return result
}

async function getUserByEmail(email) {
    await connectDatabase()
    let users = db.collection('user')
    let result = await users.findOne({email: email})
    return result
}


async function checkReset(key) {
    await connectDatabase()
    let users = db.collection('user')
    let result = await users.findOne({resetkey: key})
    return result
}

async function updateUser(user) {
    await connectDatabase()
    let userCollection = db.collection('user')
    await userCollection.replaceOne({email:user.email}, user)
}

async function updatePassword(key, pw) {
    await connectDatabase()
    let userCollection = db.collection('user')
    let user = await userCollection.findOne({resetkey: key})
    user.password = pw
    delete user.resetkey
    await userCollection.replaceOne({email:user.email}, user)
}

async function startSession(sd) {
    await connectDatabase()
    let session = db.collection('session')
    await session.insertOne(sd)
}

async function updateSession(key, data) {
    await connectDatabase()
    let session = db.collection('session')
    await session.replaceOne({key: key}, data)
}

async function getSession(key) {
    await connectDatabase()
    let session = db.collection('session')
    let result = await session.findOne({key: key})
    return result
}

async function terminateSession(key) {
    await connectDatabase()
    let session = db.collection('session')
    await session.deleteOne({key: key})
}




module.exports = {
    getUserDetails,
    startSession, updateSession, getSession, terminateSession,
    getUserByEmail, updateUser, checkReset, updatePassword
}