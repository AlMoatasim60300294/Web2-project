const express=require('express')
const business = require('./business.js')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const handlebars = require('express-handlebars')
let app = express()

app.set('views', __dirname+"/templates")
app.set('view engine', 'handlebars')
app.engine('handlebars', handlebars.engine())
app.use(bodyParser.urlencoded({extended: false}))
app.use(cookieParser())
app.use('/images', express.static(__dirname+"/static/images"))


app.get('/', (req, res) => {
    let message = req.query.message
    res.render('login', {
        message: message
    })
})

app.post('/', async (req, res) => {
    let username = req.body.uname
    let password = req.body.pw
    let session = await business.attemptLogin(username, password)
    if (session) {
        res.cookie('session', session.key, {expires: session.expiry})
        res.redirect('/dashboard')
    }
    else {
        res.redirect('/?message=Invalid Credentials')
    }
})

app.get('/dashboard', async (req, res) => {
    let sessionKey = req.cookies.session
    if (!sessionKey) {
        res.redirect("/?message=You must be logged in to see that page")
        return
    }
    let sd = await business.getSession(sessionKey)
    if (!sd) {
        res.redirect("/?message=You must be logged in to see that page")
        return
    }
    
    let username = sd.data.username
    res.render('dashboard', {
        username: username
    })
})

app.get('/logout', async (req, res) => {
    await business.terminateSession(req.cookies.sessionid)
    res.clearCookie('session')
    res.redirect('/')
})

app.get('/forgot-password', (req, res) => {
    res.render('password_reset')
})

app.post('/forgot-password', async (req, res) => {
   await business.resetPassword(req.body.email)
    res.send("Check your email for a password reset link.")
})

app.get('/reset-password', async (req, res) => {
    let checkReset = business.checkReset(req.query.key)
    if (!checkReset) {
        res.send("Invalid key")
        return
    }
    res.render("new_password", {
        key: req.query.key
    })
})

app.post('/reset-password', async (req, res) => {
    let pw = req.body.password
    let confirm = req.body.confirm
    let key = req.body.key
    if (pw != confirm) {
        res.send("Password mismatch")
        return
    }
    await business.setPassword(key, pw)
    res.redirect('/?message=Password changed')
})

app.listen(8000, () => {})