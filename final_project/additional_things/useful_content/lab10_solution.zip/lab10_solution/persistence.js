const mongodb = require('mongodb')
let client = undefined 
let db = undefined
let courseCollection = undefined

async function connectDatabase() {
    if (!client) {
        client = new mongodb.MongoClient('mongodb://127.0.0.1:27017')
        db = client.db('university')
        courseCollection = db.collection('course')
        await client.connect()
    }
}

async function getAllCourses() {
    await connectDatabase()
    let courses = await courseCollection.find({}).toArray()
    return courses
}

async function findCourse(code) {
    await connectDatabase()
    let course = await courseCollection.findOne({code:code})
    return course
}

async function updateCapacity(code, capacity) {
    await connectDatabase()
    await courseCollection.updateOne({code:code}, {$set: {capacity: capacity}})
}

async function addCourse(details) {
    await connectDatabase()
    await courseCollection.insertOne(details)
}

async function deleteCourse(course) {
    await connectDatabase()
    await courseCollection.deleteOne({code: course})
}


module.exports = {
    getAllCourses, findCourse, updateCapacity, addCourse, deleteCourse
}