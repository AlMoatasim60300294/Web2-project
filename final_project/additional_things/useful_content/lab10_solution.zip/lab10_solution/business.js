
const persistence = require('./persistence')

async function allCourses() {
    return await persistence.getAllCourses()
}
async function findCourse(code) {
    return await persistence.findCourse(code)
}

async function updateCapacity(code, capacity) {
    return persistence.updateCapacity(code, capacity)
}

async function addCourse(course) {
    return persistence.addCourse(course)
}

async function deleteCourse(course) {
    return persistence.deleteCourse(course)
}

module.exports = {
    allCourses,
    findCourse,
    updateCapacity,
    addCourse, deleteCourse
}