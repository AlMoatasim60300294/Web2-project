const express=require('express')
const business = require('./business')
const handlebars = require('express-handlebars')
const bodyParser = require('body-parser')
let app = express()

app.set('views', __dirname+"/templates")
app.set('view engine', 'handlebars')
app.engine('handlebars', handlebars.engine())
app.use(bodyParser.json())

app.get('/', (req, res) => {
    res.render('spaapp', {layout: undefined})
})

app.get('/api/course', async (req, res) => {
    res.send(await business.allCourses())
})

app.get('/api/course/:courseNumber', async (req, res) => {
    let courseNumber = req.params.courseNumber
    let details = await business.findCourse(courseNumber)
    res.send(details)
})

app.patch('/api/course/:courseNumber', async (req, res) => {
    let courseNumber = req.params.courseNumber
    let newCapacity = req.body.capacity
    await business.updateCapacity(courseNumber, newCapacity)
    res.send('ok')
})

app.post('/api/course', async (req, res) => {
    let course = req.body
    let details = await business.findCourse(course.code)
    if (details) {
        res.status(400)
        res.send("Duplicate course number")
        return
    }
    await business.addCourse(course)
    res.send('ok')
})

app.delete('/api/course/:cid', async (req, res) => {
    await business.deleteCourse(req.params.cid)
    res.send('ok')
})



app.listen(8000, () => {})